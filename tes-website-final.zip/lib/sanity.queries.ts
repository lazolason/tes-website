// Define your GROQ queries here for retrieving data
import groq from 'groq'
